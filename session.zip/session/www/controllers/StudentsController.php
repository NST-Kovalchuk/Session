<?php header("Content-type: text/html; charset=utf-8");

  include('config/config.php');

  class Group {

    public  $IdGroup;
    public  $Name;

  }

  class StudentWrap {

    public  $Id         ;//{ get; set; }
    public  $Name       ;//{ get; set; }
    public  $SerName    ;//{ get; set; }
    public  $Patronymic ;//{ get; set; }
    public  $Kurs       ;//{ get; set; }
    public  $StudGroup  ;//{ get; set; }
    public  $Email      ;//{ get; set; }
    public  $Phone      ;//{ get; set; }
  }

  class StudentsController {

    public $studJSON;

    function  __construct($mysqli) {

      //$this->$studJSON = $this->getStudentsList($mysqli);
    }



    public function getStudentsList($mysqli) {

      $query = "SELECT Students.Id as StudId, Sername, Students.Name as StudName, Patronymic, Kurs, Groups.Id as GroupId, Groups.Name as GroupName, Email, Phone
                FROM Students INNER JOIN Groups ON Students.IdGroup=Groups.Id";

      try {
        $result = $mysqli->query($query);

        if ($result) {
          $array = $result->fetch_all(MYSQLI_ASSOC);

          if (count($array) > 0) {

            for ($i = 0; $i < count($array); $i++) {
              $student = new StudentWrap($mysqli);
              $student->Id = $array[$i]['StudId'];
              $student->SerName = $array[$i]['Sername'];
              $student->Name = $array[$i]['StudName'];
              $student->Patronymic = $array[$i]['Patronymic'];
              $student->Kurs = $array[$i]['Kurs'];

              $studGroup = new Group();
              $studGroup->Id = $array[$i]['GroupId'];
              $studGroup->Name = $array[$i]['GroupName'];

              $student->StudGroup = $studGroup;

              $student->Email = $array[$i]['Email'];
              $student->Phone = $array[$i]['Phone'];

              $studArray[$i] = $student;
            }

            //return json_encode($studArray);
            return $studArray;
          } else {
            return 'No students';
          }
        }


      } catch (Exception $ex) {
        echo '! Exception: ' + $ex->getMessage() + '. Line: ' + $ex->getLine();
      }
    }

  }






?>
