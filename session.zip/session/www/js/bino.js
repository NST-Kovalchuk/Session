$(document).ready(function(){
   $(window).scroll(function () {
      if ($(this).scrollTop() > 50) {
        $("#back-to-top").fadeIn();
        $("header").addClass("fix")
        $("header").fadeIn();
      } else {
          $("#back-to-top").fadeOut();
          $("header").removeClass("fix");
        }
   });
  $("#back-to-top").click(function () {
    $("body,html").animate({
      scrollTop: 0
    }, 1000);
    return false;
  });


$(".down-btn").click( function() {
  $("body,html").animate({
    scrollTop: document.documentElement.clientHeight
  }, 1000);
  return false;
})
$("#recentWorks-tabs a").click(function (e) {
  e.preventDefault()
  $(this).tab("show")
})

	$("#navbar-collapse").on("click","a", function (event) {
		event.preventDefault();

    $(this).parent().parent().find("li").removeClass("active");
    $(this).parent().addClass("active");
		var id  = $(this).attr("href"),
		top = $(id).offset().top;
    if (id == "#pricing" || id == "#portfolio" || id == "#blog" || id == "#contact") {
      top += Number(50);
		  $("body,html").animate({scrollTop: top}, 1200);
    }
		else $("body,html").animate({scrollTop: top}, 1200);
	});

	$(".service-item-img").on("click","a", function (event) {
		event.preventDefault();
		var id  = $(this).attr("href"),
		top = $(id).offset().top + Number(50);
		$("body,html").animate({scrollTop: top}, 1200);
    if ($(this).hasClass("web-design")) {
      $(".nav-tabs li").removeClass("active");
      $("[href $= web-design]").parent().addClass("active");
      $(".tab-content").find(".tab-pane").removeClass("in");
      $(".tab-content").find(".tab-pane").removeClass("active");
      $(".tab-content").find("#web-design").addClass("in");
      $(".tab-content").find("#web-design").addClass("active");
    } else if ($(this).hasClass("print-design")) {
      $(".nav-tabs li").removeClass("active");
      $("[href $= print-design]").parent().addClass("active");
      $(".tab-content").find(".tab-pane").removeClass("in");
      $(".tab-content").find(".tab-pane").removeClass("active");
      $(".tab-content").find("#print-design").addClass("in");
      $(".tab-content").find("#print-design").addClass("active");
    } else if ($(this).hasClass("photography")) {
      $(".nav-tabs li").removeClass("active");
      $("[href $= photography]").parent().addClass("active");
      $(".tab-content").find(".tab-pane").removeClass("in");
      $(".tab-content").find(".tab-pane").removeClass("active");
      $(".tab-content").find("#photography").addClass("in");
      $(".tab-content").find("#photography").addClass("active");
    }
	});
	$(".serv-nav li").on("click","a", function (event) {
		event.preventDefault();
		var id  = $(this).attr("href"),
		top = $(id).offset().top + Number(50);
		$("body,html").animate({scrollTop: top}, 1200);
	});



$("#logo").click(function () {
  $("body,html").animate({
    scrollTop: 0
  }, 1000);
  return false;
});

$(".text-box").hover(function() {
    $(this).children().fadeToggle();
});

});
