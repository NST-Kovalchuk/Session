
function sendSMS(){

  $.post(
    "./actions/sendSMS.php",
    {message: $("#message").val()},
    function(data) { console.log(data); });

}
