<?php

  include('config/config.php');
  include('controllers/StudentsController.php');

  $Students = new StudentsController($mysqli);


  print_r($Students->getStudentsList($mysqli));

  echo "hello";

?>

<html>
	<head>
		<title>Session</title>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
	  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="./css/styles.css" rel="stylesheet">
		<link href="./css/bootstrap.min.css" rel="stylesheet">

	</head>
	<body>
	<input type="button" name="val" class="btn-default" value="sss">
  <div class="container" id="home">

    <form>
      <textarea id="message"></textarea>
      <input type="button" class="btn" value="Отправит смс" onclick="sendSMS()">
    </form>


	</div>
	<footer>

	</footer>

	</body>
	<script src="./js/jquery-2.2.2.js"></script>
	<script src="./js/bootstrap.min.js"></script>
	<script src="./js/session.js"></script>
</html>
