<?php
	$mysqli = new mysqli('localhost', 'root', '1111','StudentNotification',3306);

	if (mysqli_connect_errno()) {
	   printf("Подключение к серверу MySQL невозможно. Код ошибки: %s\n", mysqli_connect_error());
	   exit;
	}

	if (!$mysqli->set_charset("utf8")) {
	    printf("Ошибка при загрузке набора символов utf8: %s\n", $mysqli->error);
	}
?>
