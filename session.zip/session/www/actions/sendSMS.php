<?php

   $url = "https://semysms.net/api/3/sms.php"; //Адрес url для отправки СМС
   //$phone = $_POST["phone"]; // Номер телефона
   $phone = '380939245152'; // Номер телефона
   $msg = $_POST["message"];  // Сообщение
   $device = '27471';  // Код вашего устройства
   $token = 'fa4792911d46be5d2cab7c57b2cec764 ';  // Ваш токен (секретный)

   $data = array(
          "phone" => $phone,
          "msg" => $msg,
          "device" => $device,
          "token" => $token
      );

    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    $output = curl_exec($curl);
    curl_close($curl);

    echo $output;
?>
